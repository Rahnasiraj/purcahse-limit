{
    'name': 'Purchase Limit',
    'version': '15.0.1.0.0',
    'category': 'point of sale',
    'sequence': -93,
    'application': True,
    'license': 'LGPL-3',
    'depends': ['base', 'point_of_sale'],
    'data': [
        'return.xml/purchase_limit.xml',
    ],
    'assets': {
        'web.assets_backend': [
        'purchase_limit/static/src/js/purchase_limit.js',
        ],
    }
}
