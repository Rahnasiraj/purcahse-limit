odoo.define('purchase_limit.customer_selection', function(require) {
     "use strict";

         var rpc = require('web.rpc');
         const ProductScreen = require('point_of_sale.ProductScreen');
         const Registries = require('point_of_sale.Registries');
         var models = require('point_of_sale.models');
         models.load_fields('res.partner', 'purchase_limit');
         models.load_fields('res.partner', 'limit');

         const PosPurchaseLimit = (ProductScreen) =>
            class extends ProductScreen {

                async _onClickPay() {
                var customer = this.currentOrder.get_client();
                var order = this.currentOrder.get_total_with_tax();

                    if (customer) {
                        if (customer.limit){
                            var domain = [['partner_id', '=', customer.id]]
                            var total_orders = []
                            var total = 0
                            await rpc.query({
                                model: 'pos.order',
                                method: 'search_read',
                                args: [domain]
                                }).then(function(result){
                                    result.forEach(function(object){
                                    total_orders.push(object['amount_total'])
                                })
                            })
                            total_orders.forEach(element =>{
                            total += element
                            })
                            console.log(total_orders)
                            console.log(total,"total")

                            if (customer.purchase_limit < total || customer.purchase_limit < order){
                                this.showPopup('ConfirmPopup', {
                                    title: this.env._t('WARNING'),
                                    body: this.env._t('Amount exceeds the purchase limit '),
                                });
                            }
                            }
                        else{
                            this.showScreen('PaymentScreen');
                            }
                    }
                    if (!customer) {
                        this.showPopup('ConfirmPopup', {
                            title: this.env._t('WARNING'),
                            body: this.env._t('Please select a customer'),
                        });
                   }

                }
            }
         Registries.Component.extend(ProductScreen, PosPurchaseLimit);
         return ProductScreen;
});

