from odoo import fields, models


class PurchaseLimit(models.Model):
    _inherit = "res.partner"

    limit = fields.Boolean(string="Limit")
    purchase_limit = fields.Integer(string="Purchase Limit")

